#include <stdio.h>

int main(void)
{
    printf("Hello World!");
    return 0;
}
